﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            this.txtNumero1.Clear();
            this.txtNumero2.Clear();
            this.cmbOperador.Text = "";
            this.lblResultado.Text = "0";
        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOperar_Click(object sender, EventArgs e)
        {
            string operador = this.cmbOperador.Text;
            string stringIng1 = this.txtNumero1.Text;
            string stringIng2 = this.txtNumero2.Text;
            double num1 =0 ;
            double num2 =0 ;
            double resultadoDouble;
            if (double.TryParse(stringIng1, out num1) && double.TryParse(stringIng2, out num2))
            {
                Numero Num1 = new Numero(num1);
                Numero Num2 = new Numero(num2);
                resultadoDouble = Calculadora.Operar(Num1, Num2, operador);
                this.lblResultado.Text = resultadoDouble.ToString();
            }
            this.btnConvertirADecimal.Enabled = true;
            this.btnConvertirABinario.Enabled = true;
        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            string resultadoString = this.lblResultado.Text;
            string retornoString = "";

            if (resultadoString != "0")
            {
                retornoString = Numero.DecimalBinario(resultadoString);
            }
            else
            {
                retornoString = "Ingrese numero";
            }
            this.lblResultado.Text = retornoString;
            this.btnConvertirADecimal.Enabled = true;
            this.btnConvertirABinario.Enabled = false;
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            string resultadoString = this.lblResultado.Text;
            string retornoString = "";

            if (resultadoString != "0")
            {
                if(Numero.ComprobarBinario(resultadoString))
                {
                    retornoString = Numero.BinarioDecimal(resultadoString);
                }
                else
                {
                    retornoString = "No es Binario";
                }
            }
            else
            {
                retornoString = "Ingrese numero";
            }
            this.lblResultado.Text = retornoString;
            this.btnConvertirADecimal.Enabled = false;
            this.btnConvertirABinario.Enabled = true;
        }
    }
}
