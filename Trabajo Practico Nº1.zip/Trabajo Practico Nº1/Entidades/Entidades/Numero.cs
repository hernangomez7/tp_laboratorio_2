﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        private double numero;
        public Numero()
        {
            numero = 0;
        }
        public Numero(double numeroIng)
        {
            numero = numeroIng;
        }
        public Numero(string strNumero)
        {
            SetNumero = strNumero;
        }
        public string SetNumero
        {
            set
            {
                this.numero = this.ValidarNumero(value);
            }
        }
        private double ValidarNumero(string strNumero)
        {
            double retornoDouble = 0;
            if (!double.TryParse(strNumero, out retornoDouble))
            {
                retornoDouble = 0;
            }
            return retornoDouble;
        }
        public static string BinarioDecimal(string binario)
        {
            int entero = 0;
            string strRetorno = "";
            int salida = 0;
            for (int i = 1; i <= binario.Length; i++)
            {
                if (int.TryParse(binario[i - 1].ToString(), out salida))
                {
                     entero += salida * (int)Math.Pow(2, binario.Length - i);
                    strRetorno = entero.ToString();
                }
                else
                {
                    strRetorno = "Valor invalido";
                    break;
                }
            }
            return strRetorno;
        }
        public static string DecimalBinario(double entero)
        {
                return DecimalBinario(entero.ToString());
        }
        public static string DecimalBinario(string entero)
        {
            string binarioRetorno = "";
            int binarioInt;
            if (int.TryParse(entero, out binarioInt))
            {
                if (binarioInt < 0)
                {
                    binarioInt *= -1;
                }
                while (binarioInt > 0)
                {
                    binarioRetorno = (binarioInt % 2).ToString() + binarioRetorno;
                    binarioInt /=2;
                }
            }
            else
            {
                binarioRetorno = "Valor invalido";
            }
            return binarioRetorno;
        }
        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }
        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }

        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }
        public static double operator /(Numero n1, Numero n2)
        {
            double resultado;
            if (n1.numero == 0 || n2.numero == 0)
            {
                resultado = 0;
            }
            else
            {
                resultado = n1.numero / n2.numero;
            }
            return resultado;
        }
        public static bool ComprobarBinario(string entero)
        {
            bool retornoBool = true;
            for(int i=0; i< entero.Length; i++)
            {
                if(!(entero[i] == '0' || entero[i] == '1'))
                {
                    retornoBool = false;
                    break;
                }
            }
            return retornoBool;
        }
    }
}
