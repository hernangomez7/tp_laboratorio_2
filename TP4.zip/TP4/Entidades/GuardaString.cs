﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades
{
    public static class GuardaString
    {
        #region Methods

        public static bool Guardar(this string texto, string archivo)
        {
            bool retornoBool = false;
            StreamWriter ArchTxt = null;
            string DireccionDesk = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + Path.DirectorySeparatorChar;
            string Direccion = string.Format("{0}{1}", DireccionDesk, archivo);
            try
            {
                ArchTxt = new StreamWriter(Direccion, true);
                ArchTxt.WriteLine(texto);
                retornoBool = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (!object.ReferenceEquals(ArchTxt, null))
                {
                    ArchTxt.Close();
                }
            }
            return retornoBool;
        }

        #endregion
    }
}
