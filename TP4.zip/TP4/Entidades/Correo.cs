﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class Correo : IMostrar<List<Paquete>>
    {
        #region Fields

        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;

        #endregion

        #region Properties

        public List<Paquete> Paquetes
        {
            get 
            {
                return this.paquetes;
            }
            set 
            {
                this.paquetes = value;
            }
        }

        #endregion

        #region Methods

        public Correo()
        {
            this.paquetes = new List<Paquete>();
            this.mockPaquetes = new List<Thread>();
        }

        public void FinEntregas()
        {
            foreach (Thread AuxThread in this.mockPaquetes)
            {
                if (AuxThread.IsAlive == true)
                {
                    AuxThread.Abort();
                }
            }
        }

        public string MostrarDatos(IMostrar<List<Paquete>> elementos)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Paquete AuxPaquete in ((Correo)elementos).paquetes)
            {
                sb.AppendFormat("{0} para {1} ({2})\n", AuxPaquete.TrackingID, AuxPaquete.DireccionEntrega, AuxPaquete.Estado.ToString());
            }
            return sb.ToString();
        }

        #endregion

        #region Operator

        public static Correo operator +(Correo c, Paquete p)
        {
            foreach (Paquete AuxPaquete in c.paquetes)
            {
                if (AuxPaquete == p)
                {
                    throw new TrackingIdRepetidoException("Error TIR: el paquete ya se a enviado");

                }
            }
            c.paquetes.Add(p);
            Thread CicloDeVidaThread = new Thread(p.MockCicloDeVida);
            c.mockPaquetes.Add(CicloDeVidaThread);
            CicloDeVidaThread.Start(); 
            return c;
        }

        #endregion

    }
}
