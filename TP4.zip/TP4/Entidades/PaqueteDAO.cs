﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public static class PaqueteDAO
    {
        #region Fields

        static SqlConnection conexionSQL;
        static SqlCommand comandoSQL;
        
        #endregion

        #region Methods

        static PaqueteDAO()
        {
            conexionSQL = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=correo-sp-2017;Integrated Security=True");
        }

        public static bool Insertar(Paquete p)
        {
            bool retornoBool = false;
            try
            {
                comandoSQL = new SqlCommand("INSERT INTO dbo.Paquetes (direccionEntrega,trackingID,alumno) VALUES ('" + p.DireccionEntrega + "','" + p.TrackingID + "','Gomez Raul 2D')", conexionSQL);
                conexionSQL.Open();
                comandoSQL.ExecuteNonQuery();
                retornoBool = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (conexionSQL != null)
                {
                    conexionSQL.Close();
                }
                if (comandoSQL != null)
                {
                    comandoSQL.Dispose();
                }
            }
            return retornoBool;
        }

        #endregion
    }
}
