﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestInstanciaEnCorreo()
        {
            Correo c = new Correo();
            Assert.IsNotNull(c.Paquetes);
        }

        [TestMethod]
        public void TestExcepMismoPaquete()
        {
            Correo c = new Correo();
            Paquete p1 = new Paquete("SameDireccion", "1234");
            Paquete p2 = new Paquete("SameDireccion", "1234");
            try
            {
                c += p1;
                c += p2;
                Assert.Fail();
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(TrackingIdRepetidoException));
            }
        }
    }
}
