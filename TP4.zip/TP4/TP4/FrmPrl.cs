﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace TP4
{
    public partial class FrmPrl : Form
    {
        private Correo correo;

        public FrmPrl()
        {
            InitializeComponent();
            this.correo = new Correo();
        }

        private void ActualizarEstados()
        {
            this.listBxEntregado.Items.Clear();
            this.listBxEnViaje.Items.Clear();
            this.listBxIngresados.Items.Clear();

            foreach (Paquete item in correo.Paquetes)
            {
                switch (item.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        listBxIngresados.Items.Add(item);
                        break;
                    case Paquete.EEstado.EnViaje:
                        listBxEnViaje.Items.Add(item);
                        break;
                    case Paquete.EEstado.Entregado:
                        listBxEntregado.Items.Add(item);
                        break;
                }
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete p = new Paquete(this.txtBxDireccion.Text, this.mskTxtBxTrack.Text);

            p.InformarEstado += paq_InformaEstado;

            try
            {
                this.correo += p;
            }
            catch (TrackingIdRepetidoException TIRE)
            {
                MessageBox.Show(TIRE.Message);
            }

            this.ActualizarEstados();
        }

        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }

        private void FrmPrl_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.correo.FinEntregas();
        }

        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            if (elemento != null)
            {
                string datosElemento = elemento.MostrarDatos(elemento);
                this.rTxtBx.Text = datosElemento;
                datosElemento.Guardar("salida.txt");
            }
        }

        private void mostarToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)listBxEntregado.SelectedItem);
        }

        private void paq_InformaEstado(object sender, EventArgs e)
        {
            {
                if (this.InvokeRequired)
                {
                    Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                    this.Invoke(d, new object[] { sender, e });
                }
                else
                {
                    ActualizarEstados();
                }
            }
        }

    }
}
